
const { ipcRenderer } = require('electron');

// DOM
const grid = document.getElementById('grid');
const empty = document.getElementById('empty');
const searchInput = document.getElementById('searchInput');
const loadPatchBtn = document.getElementById('loadPatchBtn');
const toast = document.getElementById('toast');

// State
let allGames = [];
let filtered = [];
let currentView = 'library';

// Utils
function showToast(msg) {
  toast.textContent = msg;
  toast.className = "toast show";
  setTimeout(() => toast.className = "toast", 2200);
}
function clear(node){ while(node.firstChild) node.removeChild(node.firstChild); }

// ---------- Canonicalize patches ----------
/**
 * Accepts both "jpatch" (object with games[]) and "smjpatch" (array of game objects).
 * Each game becomes: { title, description?, tags?, versions: [{title/platform, link, tags?}] }
 */
function normalizePatch(data){
  const games = [];
  if (!data) return games;

  const pushGame = (g) => {
    if (!g) return;
    const game = {
      title: g.title || g.name || "Untitled",
      description: g.description || g.desc || "",
      tags: g.tags || g.categories || [],
      versions: []
    };
    // jpatch-style versions
    if (Array.isArray(g.versions)) {
      for (const v of g.versions) {
        if (!v) continue;
        game.versions.push({
          title: v.title || v.name || "Version",
          platform: v.platform || v.system || "",
          link: v.link || v.url || "",
          tags: v.tags || v.labels || []
        });
      }
    }
    // smjpatch – single link on the game root (treat as one "version")
    if (!game.versions.length && (g.link || g.url)) {
      game.versions.push({
        title: g.version || "Download",
        platform: g.platform || "",
        link: g.link || g.url,
        tags: g.tags || []
      });
    }
    games.push(game);
  };

  if (Array.isArray(data)) {
    data.forEach(pushGame); // smjpatch
  } else if (Array.isArray(data.games)) {
    data.games.forEach(pushGame); // jpatch
  } else if (data.title || data.name) {
    pushGame(data); // allow a single-game jpatch file
  }
  return games;
}

function processPatch(patch){
  const games = normalizePatch(patch);
  if (games.length) {
    allGames = allGames.concat(games);
    showToast(`Loaded ${games.length} item(s).`);
  } else {
    showToast("No games found in patch.");
  }
  renderLibrary();
}

// ---------- Library ----------
function gameCard(g){
  const card=document.createElement('div');
  card.className='card';
  const title=document.createElement('div');
  title.className='title';
  title.textContent=g.title;
  const desc=document.createElement('div');
  desc.className='desc';
  desc.textContent=g.description||'No description.';
  const meta=document.createElement('div');
  meta.className='meta';
  (g.tags||[]).slice(0,4).forEach(t=>{
    const b=document.createElement('span');
    b.className='tag'; b.textContent=t; meta.appendChild(b);
  });
  card.append(title, desc, meta);
  card.onclick = () => openDetails(g);
  return card;
}

function renderLibrary(){
  currentView='library';
  clear(grid);
  const list = (searchInput.value||'').trim().toLowerCase();
  filtered = allGames.filter(g => !list || g.title.toLowerCase().includes(list));
  if (!filtered.length) {
    empty.style.display='block';
    return;
  }
  empty.style.display='none';
  grid.className='grid'; // ensure grid mode
  filtered.forEach(g => grid.appendChild(gameCard(g)));
}

// ---------- Details (Versions page) ----------
function tagPill(text){
  const s=document.createElement('span'); s.className='pill'; s.textContent=text; return s;
}

function versionCard(v){
  const card=document.createElement('div');
  card.className='version-card';
  const h=document.createElement('h4'); h.textContent=v.title || "Version";
  const sub=document.createElement('div'); sub.className='subtle'; sub.textContent=v.platform || "";
  const pillWrap=document.createElement('div'); pillWrap.className='pillwrap';
  (v.tags||[]).forEach(t=> pillWrap.appendChild(tagPill(t)));
  const btn=document.createElement('button'); btn.textContent='Download';
  btn.onclick=(e)=>{ e.stopPropagation(); if(v.link) ipcRenderer.send('open-external', v.link); };
  card.append(h, sub, pillWrap, btn);
  return card;
}

function openDetails(game){
  currentView='details';
  clear(grid);
  empty.style.display='none';

  // Header
  const header=document.createElement('div');
  header.className='details-header';

  const back=document.createElement('button');
  back.className='backlink';
  back.textContent='← Back';
  back.onclick=()=>renderLibrary();

  const h1=document.createElement('h1');
  h1.textContent=game.title;

  const p=document.createElement('p');
  p.className='lead'; p.textContent=game.description || '';

  header.append(back, h1, p);

  // Versions grid
  const wrap=document.createElement('div');
  wrap.className='versions-grid';
  if (!game.versions || !game.versions.length) {
    const emptyV=document.createElement('div');
    emptyV.className='empty';
    emptyV.textContent='No versions listed for this game.';
    wrap.appendChild(emptyV);
  } else {
    game.versions.forEach(v => wrap.appendChild(versionCard(v)));
  }

  grid.className='details-view';
  grid.append(header, wrap);
}

// ---------- Search + Load ----------
searchInput.addEventListener('input', () => {
  if (currentView === 'library') renderLibrary();
});

loadPatchBtn.addEventListener('click', async () => {
  try {
    const data = await ipcRenderer.invoke('open-jpatch-dialog');
    if (data) processPatch(data);
  } catch (e) { showToast('Failed to load patch.'); }
});

// Auto-load all patches in /patches
ipcRenderer.invoke('load-patches-folder').then(results => {
  (results||[]).forEach(processPatch);
});

// First paint
renderLibrary();
