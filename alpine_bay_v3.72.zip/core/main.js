const { app, BrowserWindow, dialog, ipcMain, shell } = require('electron');
const path = require('path');
const fs = require('fs');

let mainWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1200,
    height: 800,
    minWidth: 900,
    minHeight: 600,
    webPreferences: { nodeIntegration: true, contextIsolation: false }
  });
  mainWindow.loadFile(path.join(__dirname, '../ui/index.html'));
}

app.whenReady().then(createWindow);
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });

ipcMain.handle('open-jpatch-dialog', async () => {
  const { canceled, filePaths } = await dialog.showOpenDialog({
    filters: [{ name: 'JSON', extensions: ['json'] }], properties: ['openFile']
  });
  if (canceled) return null;
  return loadPatch(filePaths[0]);
});

ipcMain.handle('load-patches-folder', async () => {
  const patchesDir = path.join(__dirname, '../patches');
  const results = [];
  if (fs.existsSync(patchesDir)) {
    const files = fs.readdirSync(patchesDir).filter(f => f.endsWith('.json'));
    for (const f of files) results.push(loadPatch(path.join(patchesDir, f)));
  }
  return results;
});

function loadPatch(file) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); }
  catch { return { error: 'Invalid JSON file' }; }
}

ipcMain.on('open-external', (_evt, url) => { if (url) shell.openExternal(url); });
